const fs = require("fs");
const path = require("path");
const axios = require("axios");

// ====================================================
// 🔧 CONFIG
// ====================================================
const PRICE_FILE = path.join(__dirname, "lastPrices.json");
const NOTIF_FILE = path.join(__dirname, "priceChanges.json");

// ====================================================
// 🔥 FUNGSI CEK HARGA TERBARU (SEMUA LAYANAN)
// ====================================================
async function cekHargaTerbaru(serviceId = null) {
    try {
        const config = require("../config.js");
        const API_KEY = config.RUMAHOTP_API_KEY;
        
        if (!API_KEY) return null;

        // 🔥 AMBIL SEMUA LAYANAN
        const resServices = await axios.get("https://www.rumahotp.io/api/v2/services", {
            headers: { "x-apikey": API_KEY }
        });

        if (!resServices.data.success) return null;

        const services = resServices.data.data || [];
        
        // 🔥 TANPA KEYWORDS - AMBIL SEMUA LAYANAN
        let targetServices = [];
        if (serviceId) {
            const found = services.find(s => String(s.service_code) === String(serviceId));
            if (found) targetServices = [found];
        } else {
            // 🔥 AMBIL SEMUA LAYANAN TANPA FILTER
            targetServices = services;
        }

        if (targetServices.length === 0) return null;

        const results = [];

        for (const service of targetServices) {
            try {
                // 🔥 AMBIL NEGARA UNTUK SETIAP LAYANAN
                const resCountries = await axios.get("https://www.rumahotp.io/api/v2/countries", {
                    params: { service_id: service.service_code },
                    headers: { "x-apikey": API_KEY }
                });

                if (!resCountries.data.success) continue;

                const countries = resCountries.data.data || [];
                
                // 🔥 CARI SEMUA NEGARA (TIDAK HANYA INDONESIA)
                // ATAU TETAP FILTER INDONESIA
                const targetCountries = countries.filter(c => 
                    c.iso_code?.toLowerCase() === 'id' || 
                    c.name?.toLowerCase().includes('indonesia')
                );

                if (targetCountries.length === 0) continue;

                for (const country of targetCountries) {
                    let providers = country.pricelist || [];
                    providers = providers.sort((a, b) => (a.price || 0) - (b.price || 0));

                    if (providers.length === 0) continue;

                    const cheapest = providers[0];

                    results.push({
                        serviceName: service.service_name,
                        serviceCode: service.service_code,
                        country: country.name,
                        countryCode: country.iso_code,
                        cheapestPrice: cheapest.price || 0,
                        cheapestProvider: cheapest.server_name || '-',
                        stock: cheapest.stock || 0,
                        allProviders: providers.map(p => ({
                            providerId: p.provider_id || p.product_code,
                            serverName: p.server_name || '-',
                            price: p.price || 0,
                            stock: p.stock || 0
                        })),
                        timestamp: new Date().toISOString()
                    });
                }

            } catch (err) {
                // SENYAP
            }
        }

        const dataToSave = {
            lastUpdate: new Date().toISOString(),
            services: results
        };
        
        fs.writeFileSync(PRICE_FILE, JSON.stringify(dataToSave, null, 2));

        return results;

    } catch (err) {
        return null;
    }
}

// ====================================================
// 🔥 CEK PERUBAHAN HARGA
// ====================================================
async function cekPerubahanHarga() {
    try {
        let lastData = { services: [] };
        if (fs.existsSync(PRICE_FILE)) {
            lastData = JSON.parse(fs.readFileSync(PRICE_FILE, "utf8"));
        }

        const newData = await cekHargaTerbaru();
        if (!newData || newData.length === 0) return null;

        const changes = [];

        for (const newService of newData) {
            const oldService = lastData.services?.find(s => 
                s.serviceCode === newService.serviceCode &&
                s.country === newService.country
            );

            if (!oldService) {
                changes.push({
                    serviceName: newService.serviceName,
                    serviceCode: newService.serviceCode,
                    country: newService.country,
                    countryCode: newService.countryCode,
                    oldPrice: 0,
                    newPrice: newService.cheapestPrice,
                    oldStock: 0,
                    newStock: newService.stock,
                    oldProvider: '-',
                    newProvider: newService.cheapestProvider,
                    priceDiff: newService.cheapestPrice,
                    pricePercent: 0,
                    stockDiff: newService.stock,
                    isNew: true,
                    isPriceChanged: true,
                    isStockChanged: true,
                    isSignificant: true,
                    timestamp: new Date().toISOString()
                });
                continue;
            }

            const oldPrice = oldService.cheapestPrice || 0;
            const newPrice = newService.cheapestPrice || 0;
            const oldStock = oldService.stock || 0;
            const newStock = newService.stock || 0;
            const oldProvider = oldService.cheapestProvider || '-';
            const newProvider = newService.cheapestProvider || '-';

            const priceDiff = newPrice - oldPrice;
            const pricePercent = oldPrice > 0 ? (priceDiff / oldPrice) * 100 : 0;
            const stockDiff = newStock - oldStock;

            const isPriceChanged = priceDiff !== 0;
            const isStockChanged = stockDiff !== 0;
            const isSignificant = Math.abs(pricePercent) > 5 || priceDiff > 1000 || stockDiff > 50;

            if (isPriceChanged || isStockChanged) {
                changes.push({
                    serviceName: newService.serviceName,
                    serviceCode: newService.serviceCode,
                    country: newService.country,
                    countryCode: newService.countryCode,
                    oldPrice: oldPrice,
                    newPrice: newPrice,
                    oldStock: oldStock,
                    newStock: newStock,
                    oldProvider: oldProvider,
                    newProvider: newProvider,
                    priceDiff: priceDiff,
                    pricePercent: pricePercent,
                    stockDiff: stockDiff,
                    isNew: false,
                    isPriceChanged: isPriceChanged,
                    isStockChanged: isStockChanged,
                    isSignificant: isSignificant,
                    timestamp: new Date().toISOString()
                });
            }
        }

        if (changes.length > 0) {
            let allChanges = [];
            if (fs.existsSync(NOTIF_FILE)) {
                allChanges = JSON.parse(fs.readFileSync(NOTIF_FILE, "utf8"));
            }
            allChanges = [...changes, ...allChanges];
            if (allChanges.length > 500) allChanges = allChanges.slice(0, 500);
            fs.writeFileSync(NOTIF_FILE, JSON.stringify(allChanges, null, 2));
        }

        return changes;

    } catch (err) {
        return null;
    }
}

// ====================================================
// 🔥 KIRIM NOTIFIKASI KE CHANNEL
// ====================================================
async function sendPriceNotification(bot, channelUsername, changes) {
    if (!changes || changes.length === 0) return;

    const now = new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" });
    
    const significant = changes.filter(c => c.isSignificant);
    const minor = changes.filter(c => !c.isSignificant);

    let caption = `
<blockquote>
<b>📊 UPDATE HARGA NOKOS</b>
━━━━━━━━━━━━━━━━━━━
📅 <b>Waktu:</b> ${now}
━━━━━━━━━━━━━━━━━━━
`;

    if (significant.length > 0) {
        caption += `<b>⚠️ PERUBAHAN SIGNIFIKAN:</b>\n`;
        for (const c of significant) {
            const emoji = c.priceDiff > 0 ? '📈' : c.priceDiff < 0 ? '📉' : '➖';
            const priceChange = c.priceDiff > 0 ? `+Rp${c.priceDiff.toLocaleString("id-ID")}` : 
                               c.priceDiff < 0 ? `-Rp${Math.abs(c.priceDiff).toLocaleString("id-ID")}` : 'Tidak berubah';
            
            caption += `
${emoji} <b>${c.serviceName}</b> (${c.country})
   💰 <b>Harga:</b> Rp${c.oldPrice.toLocaleString("id-ID")} → <b>Rp${c.newPrice.toLocaleString("id-ID")}</b>
   📊 ${priceChange} (${c.pricePercent > 0 ? '+' : ''}${c.pricePercent.toFixed(2)}%)
   📦 <b>Stok:</b> ${c.oldStock} → ${c.newStock}
   🏷️ Provider: ${c.oldProvider} → ${c.newProvider}
`;
        }
        caption += `━━━━━━━━━━━━━━━━━━━\n`;
    }

    if (minor.length > 0) {
        caption += `<b>ℹ️ Perubahan Kecil:</b>\n`;
        for (const c of minor) {
            const emoji = c.priceDiff > 0 ? '📈' : c.priceDiff < 0 ? '📉' : '➖';
            caption += `${emoji} ${c.serviceName} (${c.country}): Rp${c.oldPrice.toLocaleString("id-ID")} → Rp${c.newPrice.toLocaleString("id-ID")} (stok: ${c.oldStock} → ${c.newStock})\n`;
        }
    }

    const newServices = changes.filter(c => c.isNew);
    if (newServices.length > 0) {
        caption += `━━━━━━━━━━━━━━━━━━━\n`;
        caption += `<b>🆕 Layanan Baru:</b>\n`;
        for (const c of newServices) {
            caption += `🆕 ${c.serviceName} (${c.country}): Rp${c.newPrice.toLocaleString("id-ID")} (stok: ${c.newStock})\n`;
        }
    }

    caption += `
━━━━━━━━━━━━━━━━━━━
🤖 <i>Real-time Monitor • Notifikasi instan</i>
</blockquote>
`;

    try {
        let cleanUsername = channelUsername
            .replace('https://t.me/', '')
            .replace('@', '')
            .trim();
        
        if (cleanUsername) {
            const chat = await bot.getChat(`@${cleanUsername}`);
            const channelId = chat.id;
            
            await bot.sendMessage(channelId, caption, {
                parse_mode: "HTML",
                disable_web_page_preview: true
            });
        }
    } catch (err) {
        try {
            const config = require("../config.js");
            if (config.idchannel) {
                await bot.sendMessage(config.idchannel, caption, {
                    parse_mode: "HTML",
                    disable_web_page_preview: true
                });
            }
        } catch (err2) {}
    }

    return caption;
}

// ====================================================
// 🔥 AUTO MONITOR - CEK SETIAP 10 DETIK (SENYAP)
// ====================================================
function startPriceMonitor(bot, channelUsername, intervalMs = 10000) {
    let isChecking = false;

    setTimeout(async () => {
        const changes = await cekPerubahanHarga();
        if (changes && changes.length > 0) {
            await sendPriceNotification(bot, channelUsername, changes);
        }
    }, 3000);

    const interval = setInterval(async () => {
        if (isChecking) return;
        isChecking = true;
        
        try {
            const changes = await cekPerubahanHarga();
            if (changes && changes.length > 0) {
                await sendPriceNotification(bot, channelUsername, changes);
            }
        } catch (err) {
            // SENYAP
        } finally {
            isChecking = false;
        }
    }, intervalMs);

    return interval;
}

// ====================================================
// 🔥 GET HARGA TERMURAH
// ====================================================
async function getCheapestPrice(serviceName = null) {
    try {
        const data = await cekHargaTerbaru();
        if (!data) return null;

        let target = data;
        if (serviceName) {
            target = data.filter(s => 
                s.serviceName.toLowerCase().includes(serviceName.toLowerCase())
            );
        }

        if (target.length === 0) return null;

        return target.map(s => ({
            service: s.serviceName,
            country: s.country,
            price: s.cheapestPrice,
            provider: s.cheapestProvider,
            stock: s.stock,
            timestamp: s.timestamp
        }));

    } catch (err) {
        return null;
    }
}

// ====================================================
// 🔥 COMMAND CEK HARGA
// ====================================================
async function cmdCekHarga(bot, chatId, keyword = null) {
    try {
        const loading = await bot.sendMessage(chatId, "⏳ *Mengecek harga terbaru...*", {
            parse_mode: "Markdown"
        });

        const data = await getCheapestPrice(keyword);
        
        if (!data || data.length === 0) {
            await bot.editMessageText(`❌ Tidak ada data harga untuk "${keyword || 'semua layanan'}"`, {
                chat_id: chatId,
                message_id: loading.message_id,
                parse_mode: "Markdown"
            });
            return;
        }

        let caption = `
<blockquote>
<b>📊 HARGA TERBARU NOKOS</b>
━━━━━━━━━━━━━━━━━━━
📅 ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}
━━━━━━━━━━━━━━━━━━━
`;

        data.forEach((item, i) => {
            caption += `
${i + 1}. <b>${item.service}</b>
   🌍 ${item.country}
   💰 <b>Rp${item.price.toLocaleString("id-ID")}</b>
   🏷️ ${item.provider}
   📦 Stok: ${item.stock}
`;
        });

        caption += `
━━━━━━━━━━━━━━━━━━━
🔄 <i>Real-time monitoring</i>
</blockquote>
`;

        await bot.editMessageCaption(caption, {
            chat_id: chatId,
            message_id: loading.message_id,
            parse_mode: "HTML"
        });

    } catch (err) {
        await bot.sendMessage(chatId, `❌ Error: ${err.message}`, {
            parse_mode: "Markdown"
        });
    }
}

// ====================================================
// 🔥 COMMAND CEK STATUS MONITOR
// ====================================================
async function cmdStatusMonitor(bot, chatId) {
    try {
        let caption = `
<blockquote>
<b>📊 STATUS PRICE MONITOR</b>
━━━━━━━━━━━━━━━━━━━━━━━
✅ <b>Status:</b> Aktif (Real-time)
🔄 <b>Interval:</b> 10 detik
📅 <b>Update Terakhir:</b> ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}
`;

        if (fs.existsSync(PRICE_FILE)) {
            const data = JSON.parse(fs.readFileSync(PRICE_FILE, "utf8"));
            const totalServices = data.services?.length || 0;
            caption += `📱 <b>Layanan Dipantau:</b> ${totalServices}\n`;
            
            if (data.services && data.services.length > 0) {
                caption += `\n<b>📋 Harga Terakhir:</b>\n`;
                data.services.forEach(s => {
                    caption += `• ${s.serviceName} (${s.country}): Rp${s.cheapestPrice.toLocaleString("id-ID")} (stok: ${s.stock})\n`;
                });
            }
        } else {
            caption += `📱 <b>Layanan Dipantau:</b> Belum ada data\n`;
        }

        caption += `
━━━━━━━━━━━━━━━━━━━━━━━
📢 <b>Channel Notifikasi:</b> ${channelUsername || 'Tidak diset'}
</blockquote>
`;

        await bot.sendMessage(chatId, caption, { parse_mode: "HTML" });
    } catch (err) {
        await bot.sendMessage(chatId, `❌ Error: ${err.message}`, {
            parse_mode: "Markdown"
        });
    }
}

// ====================================================
// 🔥 EXPORT
// ====================================================
module.exports = {
    cekHargaTerbaru,
    cekPerubahanHarga,
    sendPriceNotification,
    startPriceMonitor,
    getCheapestPrice,
    cmdCekHarga,
    cmdStatusMonitor,
    PRICE_FILE,
    NOTIF_FILE
};