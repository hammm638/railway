module.exports = {
  TOKEN: "8821597292:AAHGMWhGdI7rmVa8MS8URWtkhi8PvGl5Y8g",
  OWNER_ID: "7523570109",
  botName: "OrderRumahOtp_bot",
  version: "1.0",
  authorName: "@flowpeachieee",
  ownerName: "flowpeachieee",
  urladmin: "https://t.me/flowpeachieee",
  urlchannel: "https://t.me/GateOfOlympussss",
  idchannel: "-1003098613491",
  RUMAHOTP_API_KEY: "rk-dev-XK6fNJ6weeTLnpboIJJS8NbFksiCHukJ",  
  ppthumb: "https://files.catbox.moe/lu2bq9.jpg",  
  UNTUNG_NOKOS: 100,
  UNTUNG_DEPOSIT: 100,

};